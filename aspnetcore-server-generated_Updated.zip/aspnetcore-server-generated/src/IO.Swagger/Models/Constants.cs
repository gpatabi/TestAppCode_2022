﻿using Microsoft.Extensions.Configuration;
using System;
using System.Runtime.Serialization;

namespace IO.Swagger.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class Constants
    {
        /// <summary>
        /// 
        /// </summary>
        public const string OAuthClientId = "";
        /// <summary>
        /// 
        /// </summary>
        public const string OAuthClientSecret = "";
    }
    
}
