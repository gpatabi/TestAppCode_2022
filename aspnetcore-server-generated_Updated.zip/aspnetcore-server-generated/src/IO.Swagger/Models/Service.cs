﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace IO.Swagger.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class Service
    {
        /// <summary>
        /// 
        /// </summary>
        public static string GetAccessToken(string oAuthClientId, string oAuthClientSecret, string oAuthAccessTokenURL)
        {
            //ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            //ServicePointManager.Expect100Continue = true;
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | SecurityProtocolType.Ssl3;

            string authToken = string.Empty;
            using (var client = new HttpClient())
            {
                //client.BaseAddress = oAuthUri;
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var postData = new List<KeyValuePair<string, string>>();
                //postData.Add(new KeyValuePair<string, string>("refresh_token", _refreshToken));
                postData.Add(new KeyValuePair<string, string>("grant_type", "client_credentials"));
                postData.Add(new KeyValuePair<string, string>("client_id", oAuthClientId));
                postData.Add(new KeyValuePair<string, string>("client_secret", oAuthClientSecret));

                HttpContent content = new FormUrlEncodedContent(postData);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");

                var responseResult = client.PostAsync(oAuthAccessTokenURL, content).Result;
                authToken = responseResult.Content.ReadAsStringAsync().Result;
            }
            return authToken;
        }
    }
}
